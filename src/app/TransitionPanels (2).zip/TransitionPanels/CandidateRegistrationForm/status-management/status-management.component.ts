import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TransitionService } from '../../Service/transition-service.service';

@Component({
  selector: 'app-status-management',
  templateUrl: './status-management.component.html',
  styleUrls: ['./status-management.component.css']
})
export class StatusManagementComponent implements OnInit {
  @Input() candidateRegistration:any;
  statusForm: FormGroup = new FormGroup({});
  Titles: any =['Mr','Mrs','Miss','Ms','Dr','Prof','Other'];
  countryLogged = localStorage.getItem("country");
  isdCode = (this.countryLogged == 'US') ? '+1' : '+91';
  constructor(private fb: FormBuilder,  private transitionService: TransitionService) {
    this.statusForm = fb.group({
      emailid:['', [Validators.required]],
      contactno:['', [Validators.required]],
      currentTitle:['', [Validators.required]],
      firstname: ['', [Validators.required]],
      middlename:[''],
      lastname: ['', [Validators.required]],
      skills:['', [Validators.required]],
      dateOfBirth:['', [Validators.required]],
      currentLocation:['', [Validators.required]],
      password: ['', [Validators.required, Validators.pattern('((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')]],
      confirmPassword: ['', [Validators.required]],
    });

  }
  ngOnInit(): void {
     console.log('got data in application form---',this.candidateRegistration);
  }

  submitStatusMgmt(){
    let data = this.statusForm.value;
    console.log('data', data);
    this.transitionService.saveApplication(data).subscribe((result) => {
      if (result) {
        this.statusForm.reset();
      }
    });
  }
}
