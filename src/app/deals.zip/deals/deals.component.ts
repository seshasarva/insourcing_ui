import { Component, AfterViewInit , OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {FormGroup, FormBuilder, Validators, FormArray} from '@angular/forms';
import { DealsService } from './deals.service';
import {DealListing} from '../Models/dealListing.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-deals',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.css']
})
export class DealsComponent implements AfterViewInit, OnInit  {
  dataSource = new MatTableDataSource<DealListing>([]);
  displayedColumns: string[] = ['selected', 'dealID', 'startDate', 'access', 'status','createdBy', 'company',  'geography'];
  selectedElement: DealListing;
  public dealForm: FormGroup;
  kickOfPeopleTransition: boolean | null = null;
  fileToUpload: File = null;
 // dealNoteFileNames: string[] = [];
  dealUploadedFileId: string[] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private fb: FormBuilder, private dealsService: DealsService, private router: Router) {
    this.dealForm = this.fb.group({
      id: [null],
      monthOfCreation: ['', Validators.required],
      oppurtunityId: [''],
      clientName: [''],
      dealStatus: [''],
      businessSpocName: [''],
      clientInteraction: [''],
      iouOrIsu: [''],
      dealValue: [''],
      workArea: [''],
      peopleTransistion: [''],
      kickOffPeopleTransistion: [''],
      globalDeal: [''],
      dealLocation: [''],
      geographyWithInScope: [''],
      dealLead: [''],
      serviceCommencementDate: [''],
      offerReleaseMonth: [''],
      proposedJoiningDate: [''],
      numberOfOffersToBeReleased: [''],
      offerReleasedThrough: [''],
      hasExceptions: [''],
      exceptionCategory: [''],
      exceptionSummary: [''],
      exceptionApprovedBy: [''],
 
      hrTransitionManager: [''],
      dealNote: [''],
      dealAttachments: this.fb.array([])
    });
    this.dealForm.get('peopleTransistion').valueChanges.subscribe((value) => {
      console.log('value', value);
      this.kickOfPeopleTransition = value && value === 'Yes' ? null : true;

    });
   }

   get dealAttachments() : FormArray {
    return this.dealForm.get("dealAttachments") as FormArray
  }

  newdealNoteAttachment(name): FormGroup {
    return this.fb.group({
      fieldName: "dealNote",
      fileName: name
    })
  }

  addNewDealNoteAttachment(name) {
    this.dealAttachments.push(this.newdealNoteAttachment(name));
  }

   ngOnInit(): void {
    console.log('inside oninit');
    this.dataSource = new MatTableDataSource([]);
    this.getAllDeals();
    this.dealsService.setDealId(null);
  }

  ngAfterViewInit(){
    console.log('inside afer view in it');
    this.dataSource.paginator = this.paginator;
  }
  getAllDeals() {
    this.dealsService.fetchAllDeals().subscribe((results) => {
      console.log('inisde candidate ts ===>', results);
      if (!results) {
        return;
      }
      this.dataSource.data = results.sort((a, b) => b.id - a.id);
    });
  }

  editDeals(){
    console.log('clicked on edit', this.selectedElement);
    this.dealsService.setDealId(this.selectedElement.id);
    this.router.navigate(['/', {outlets: { primary: ['navpage', {outlets: { innerContent: ['dealsEdit']}}]}}]);
  }

  submitForm(){
	  let  data = this.dealForm.value;
    data["attachmentIds"]=[];
    //let data = {createData:this.dealForm.value, attachmentIds:{dealNote:this.dealUploadedFileId}};
    console.log(this.dealForm);
    console.log("data", data);
    this.dealsService.createDeal(data).subscribe((result) => {
      if (result) {
       // this.dealNoteFileNames = [];
        this.dealUploadedFileId= [];
        this.getAllDeals();
		
      }
    });
  }

  handleFileInput(files: FileList){
    this.fileToUpload = files.item(0);
    this.addNewDealNoteAttachment(this.fileToUpload.name);
    this.dealsService.dealNoteFileUpload(this.fileToUpload).subscribe(data => {
      if(data){
       // this.dealNoteFileNames.push(this.fileToUpload.name);
       this.dealUploadedFileId.push(data.toString());
      }
      // do something, if upload success
      }, error => {

        //change this code to success condition once integarted with backend and delete from error block
       // this.dealNoteFileNames.push(this.fileToUpload.name);
       this.dealUploadedFileId.push('12345');
        console.log(error);
      });
  }

}

  