import { Component, OnInit, Input } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TransitionService } from '../../transition.service';
@Component({
  selector: 'app-application-form',
  templateUrl: './application-form.component.html',
  styleUrls: ['./application-form.component.css']
})
export class ApplicationFormComponent implements OnInit {
  @Input() candidateRegistration:any;
  applicationForm: FormGroup = new FormGroup({});
  countryLogged = localStorage.getItem("country");
  isdCode = (this.countryLogged == 'US') ? '+1' : '+91';
  showError: false;
  constructor(
    private fb: FormBuilder,
    private transitionService: TransitionService,
  ) {
    this.applicationForm = this.fb.group({
      title: [''],
      firstName: [''],
      middleName: [''],
      lastName: [''],
      contactNo: [''],
      emailid: [''],
      streetAddress: [''], 
      apartmentUnit: [''],
      state: [''],
      zipCode: [''],
      city: [''],
      country: [''],
      date: [''],
      dateAvailable: [''],
      currentWorkLocation: [''],
      //totalExp: [''],
      totalExpYrs: [''],
      totalExpMts: [''],
      totalRelExpYrs: [''],
      totalRelExpMts: [''],
      //totalRelExp: [''],
      //   under18ProvideWorkPermit : ['Yes'],
      // offerEmpExtDemWorkUS : ['Yes'],
      // reqSponsorship : ['Yes'],
      exTCSEmployee: [''],
      under18ProvideWorkPermit: [''],
      offerEmpExtDemWorkUS: [''],
      reqSponsorship: [''],
      ifYesWhen: [''],
      exTCSStartDate: [''],
      exTCSEndDate: [''],
      companies: this.fb.array([this.fb.group({
        companyName: [''],
        address: [''],
        supervisorName: [''],
        supervisorContact: [''],
        jobTitle: [''],
        responsibilities: '',
        startDate: [''],
        endDate: [''],
        reasonForLeaving: [''],
        comMayContactSupervisorRef: "Yes"
      })]),
      courses: this.fb.array([this.fb.group({
        educationalLevel: '',
        instituteName: '',
        insAddress: '',
        graduate: 'Yes',
        degree: '',
        cos: '',
        GPA: '',
      })]),
      skills: this.fb.array([this.fb.group({
        skillTech: '',
        description: ''
      })]),
      references: this.fb.array([this.fb.group({
        fullName: '',
        relationship: '',
        comName: '',
        contactNo: '',
        emailId: '',
        address: ''
      })]),
      militaryExp: [''],
      signName: [''],
      signature: [''],
      signDate: [''],
      lawSignature: ['']

    });

    this.applicationForm.get('exTCSEmployee').valueChanges.subscribe((value) => {
      console.log('value is----', value);
    });
  }

  get companies(): FormArray {
    return this.applicationForm.get('companies') as FormArray;
  }

  get courses(): FormArray {
    return this.applicationForm.get('courses') as FormArray;
  }

  get skills(): FormArray {
    return this.applicationForm.get('skills') as FormArray;
  }

  get references(): FormArray {
    return this.applicationForm.get('references') as FormArray;
  }

  ngOnInit(): void {
    //this.getApplication();
    console.log('got data in application form---',this.candidateRegistration);

  }

  getApplication() {
    this.transitionService.fetchCandidateReg().subscribe((result) => {
      console.log('result is----', result);
    });
  }

  submitApplication() {
    let data = this.applicationForm.value;
    console.log('data', data);
    this.transitionService.saveApplication(data).subscribe((result) => {
      if (result) {
        // this.dealNoteFileNames = [];
        this.applicationForm.reset();
      }
    });
  }

  addcompany() {
    (this.applicationForm.get('companies') as FormArray).push(this.fb.group({
      companyName: '',
      address: '',
      jobTitle: '',
      supervisorName: '',
      supervisorContact: '',
      responsibilities: '',
      startDate: '',
      endDate: '',
      reasonForLeaving: '',
      comMayContactSupervisorRef: ''
    }));
  }

  addCourse() {
    (this.applicationForm.get('courses') as FormArray).push(this.fb.group({
      educationalLevel: '',
      instituteName: '',
      insAddress: '',
      graduate: 'Yes',
      degree: '',
      cos: '',
      GPA: '',
    }));
  }

  addSkill() {
    (this.applicationForm.get('skills') as FormArray).push(this.fb.group({
      skillTech: '',
      description: ''
    }));
  }

  addReference() {
    (this.applicationForm.get('references') as FormArray).push(this.fb.group({
      fullName: '',
      relationship: '',
      comName: '',
      contactNo: '',
      emailId: '',
      address: ''
    }));
  }

  removeCompanies(i: number) {
    this.companies.removeAt(i);
  }

  removeCourse(i: number) {
    this.courses.removeAt(i);
    //this.courses.splice(i, 1);
  }

  removeSkill(i: number) {
    this.skills.removeAt(i);
    // this.skills.splice(i, 1);
  }

  removeReference(i: number) {
    this.references.removeAt(i);
    //this.references.splice(i, 1);
  }
}

